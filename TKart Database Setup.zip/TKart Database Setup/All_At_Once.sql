create database tkart_auth;
use tkart_auth;

CREATE TABLE `user_details` (
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(128) DEFAULT NULL,
  `type` varchar(1) NOT NULL,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`email`)
);

create database tkart_sellers;
use tkart_sellers;

create table catagory_details(catagory_id int(20) auto_increment not null,
  catagory_name varchar(100) not null,
  sub_catagory_name varchar(100) not null,
  modify_date timestamp not null,
  added_date timestamp not null,
  primary key(catagory_name,
  sub_catagory_name),
  unique(catagory_id)
  );

create table product_details(product_id int(11) auto_increment not null,
  product_name varchar(100) not null,
  catagory_id int(20) not null,
  price double(10,2) not null,
  path varchar(100),
  quantity int(5) not null,
  sold int(9) not null,
  technical_details text(25000),
  modify_date timestamp not null,
  added_date timestamp not null, 
  primary key (product_id), 
  foreign key (catagory_id) references catagory_details(catagory_id)
  );
create table offer_details(product_id varchar(20) not null,
  offer int(3) NOT NULL DEFAULT '0', 
  from_date date not null,
  to_date date not null,
  modify_date timestamp not null,
  added_date timestamp not null, 
  primary key(product_id)
  );

create table shipto_details(pincode int(6) not null,
  tax double(10,2) not null,
  delivery_charges double(10,2) not null,
  modify_date timestamp not null,
  added_date timestamp not null,
  primary key(pincode)
  );



  
create database tkart_customers;

use tkart_customers;

create table address_details(address_id int(100) auto_increment not null,
  email varchar(100) not null,
  present_address varchar(100) not null,
  alternative_address varchar(100),
  city varchar(25) not null,
  state varchar(25) not null,
  pincode int(6) not null,
  landmark varchar(50),
  modify_date timestamp not null,
  added_date timestamp not null,
  primary key(address_id),
  foreign key (email) references tkart_auth.user_details(email),
  foreign key (pincode) references tkart_sellers.shipto_details(pincode)
  );

create table order_details(order_id int(20) auto_increment not null,
  email varchar(100) not null,
  product_id int(20) not null,
  address_id int(100) not null,
  delivery_date timestamp not null,
  order_date timestamp not null,
  deliver varchar(1),
  total_bill double(10,2) not null,
  primary key(order_id),
  foreign key (email) references tkart_auth.user_details(email),
  foreign key (product_id) references tkart_sellers.product_details(product_id),
  foreign key (address_id) references address_details(address_id)
  );

	
use tkart_sellers;
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (560056,0.00,0.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (560071,0.00,45.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (560072,45.00,43.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (560073,3.40,56.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (560091,32.00,12.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (571418,24.00,58.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (571419,23.00,76.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (626125,23.00,87.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (770001,12.00,63.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (829113,23.00,98.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');
INSERT INTO `shipto_details` (`pincode`,`tax`,`delivery_charges`,`modify_date`,`added_date`) VALUES (834001,16.00,72.00,'2016-12-31 21:32:53','0000-00-00 00:00:00');

	
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (1,'electronics','mobiles');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (2,'electronics','mobile accessories');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (3,'electronics','laptops');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (4,'electronics','tvs');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (5,'electronics','camera');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (6,'appliances','washing machine');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (7,'appliances','refrigerator');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (8,'appliances','air conditioners');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (9,'appliances','geysers');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (10,'appliances','kitchen appliances');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (11,'appliances ','small home appliances');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (12,'men','footwear');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (13,'men','clothing');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (14,'men','watches');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (15,'men','accessories');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (16,'men','mens grooming');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (17,'men','accessories');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (18,'men','personal care appliances');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (19,'women','clothing');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (20,'women','footwear');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (21,'women','watches');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (22,'women','jewellery');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (23,'women','beauty and grooming');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (24,'women','accessories');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (25,'babys and kids','kids clothing');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (26,'babys and kids','toys');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (27,'babys and kids','baby care');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (28,'babys and kids','babys clothing');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (29,'home and furniture','furniture');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (30,'home and furniture','home decorators');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (31,'home and furniture','dining');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (32,'home and furniture','kitchen storage');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (33,'home and furniture','furnishing');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (34,'home and furniture','lighting');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (35,'home and furniture','dining and serving');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (36,'books and more','books');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (37,'books and more','gaming');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (38,'books and more','automobiles');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (39,'books and more','music');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (40,'books and more','sports');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (41,'books and more ','stationary');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (42,'electronics','network components');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (43,'electronics','tablets');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (44,'electronics','camera accessories');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (45,'electronics','home entertainmenr');
INSERT INTO `catagory_details` (`catagory_id`,`catagory_name`,`sub_catagory_name`) VALUES (46,'electronics','wearable');

use tkart_auth;
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('Praveen','null','M',9999999999,'praveen@gmail.com','63a9f0ea7bb98050796b649e85481845','A');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('aatish','null','Azad',9999999999,'aatish@gmail.com','63a9f0ea7bb98050796b649e85481845','A');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('kiran','null','k',8123456789,'kiran@gmail.com','63a9f0ea7bb98050796b649e85481845','M');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('megha','null','m',8765432210,'megha@gmail.com','63a9f0ea7bb98050796b649e85481845','M');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('nithya','null','d',9999999999,'nithya@gmail.com','63a9f0ea7bb98050796b649e85481845','M');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('preethi','null','p',9999999999,'preethi@gmail.com','63a9f0ea7bb98050796b649e85481845','N');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('priyanka','null','p',7777777777,'priyanka@.com','63a9f0ea7bb98050796b649e85481845','N');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('shashank','null','s',9999999999,'shashank@gmail.com','63a9f0ea7bb98050796b649e85481845','M');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('sonali','null','s',8888888888,'sonali@gmail.com','63a9f0ea7bb98050796b649e85481845','N');
INSERT INTO `user_details` (`first_name`,`middle_name`,`last_name`,`mobile_no`,`email`,`password`,`type`) VALUES ('vijay','null','v',9999999999,'vijay@gmail.com','63a9f0ea7bb98050796b649e85481845','M');


use tkart_sellers;
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (1,'Apple iphone 5',1,4535.00,'\\TKart\\images\\11Apple iPhone 5.jpg',43,0,'IPhone','2017-01-03 00:51:44','2017-01-03 00:51:44');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (2,'Micromax Canvas',1,654.00,'\\TKart\\images\\22Micromax Canvas.jpg',34,0,'This is a SmartPhone','2017-01-03 00:53:27','2017-01-03 00:52:31');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (3,'Nokia 1100',1,1100.00,'\\TKart\\images\\38Nokia1100.jpg',4523,0,'This is a SmartPhone','2017-01-03 00:54:02','2017-01-03 00:54:02');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (4,'Moto Moto X',1,67.00,'\\TKart\\images\\43motorola Moto X.jpg',67,0,'This is a SmartPhone','2017-01-03 00:54:45','2017-01-03 00:54:45');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (5,'Sonata',14,1900.00,'\\TKart\\images\\5116055.jpg',2,0,'Good Time','2017-01-03 14:54:57','2017-01-03 14:54:57');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (6,'Home theatre system',45,12594.00,'\\TKart\\images\\6images.jpg',1,0,'A massive home entertainment ','2017-01-03 14:58:19','2017-01-03 14:58:19');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (8,'Jeans shoe',12,1200.00,'\\TKart\\images\\8download.jpg',3,0,'Walking smoothly ','2017-01-03 15:01:54','2017-01-03 15:01:54');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (9,'Slipper',12,1700.00,'\\TKart\\images\\9download (1).jpg',3,0,'Walk very smoothly ','2017-01-03 15:03:11','2017-01-03 15:03:11');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (10,'Stylish shoe',12,1800.00,'\\TKart\\images\\10images (1).jpg',3,0,'Walking stylish','2017-01-03 15:04:15','2017-01-03 15:04:15');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (11,'Creative E2400 Home Theatre System',45,2250.00,'\\TKart\\images\\1141Aa2-QYxpL._SY400_.jpg',1,0,'High performance speaker system.','2017-01-03 15:05:38','2017-01-03 15:05:38');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (14,'Sony Blu ray disk/ Dvd player',45,11999.00,'\\TKart\\images\\1431e+dabv5nL._SY400_.jpg',1,0,'Dvd player with inbuilt WiFi','2017-01-03 15:13:24','2017-01-03 15:13:24');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (16,'Hat',15,300.00,'\\TKart\\images\\16images (8).jpg',9,0,'Looking casual','2017-01-03 15:16:04','2017-01-03 15:16:04');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (19,'LG',8,650.00,'\\TKart\\images\\19Air conditioner.jpg',10,0,'this is an AC','2017-01-03 15:24:36','2017-01-03 15:24:36');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (21,'VIdeocon ',8,1200.00,'\\TKart\\images\\21videocon ac.jpg',5,0,'This is an air conditioner','2017-01-03 15:26:42','2017-01-03 15:26:42');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (22,'Roxy Gyser',9,500.00,'\\TKart\\images\\22GYSER!.jpg',10,0,'THIs is an gyser','2017-01-03 15:28:08','2017-01-03 15:28:08');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (23,'City of Thieves',37,1000.00,'\\TKart\\images\\23images (10).jpg',5,0,'Thieves city','2017-01-03 15:28:29','2017-01-03 15:28:29');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (24,'Refregerator',10,5000.00,'\\TKart\\images\\24freeze.jpg',12,0,'THis is an Refregerator','2017-01-03 15:30:11','2017-01-03 15:30:11');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (25,'Rest is Noise',39,500.00,'\\TKart\\images\\25images.png',4,0,'Noise with music','2017-01-03 15:31:24','2017-01-03 15:31:24');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (26,'Cooking Pans',11,200.00,'\\TKart\\images\\26pans.jpg',10,0,'This is cooking pan','2017-01-03 15:32:02','2017-01-03 15:32:02');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (27,'Wild pitch',40,400.00,'\\TKart\\images\\27images (11).jpg',4,0,'Wilding','2017-01-03 15:33:25','2017-01-03 15:33:25');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (28,'Bracelets',24,300.00,'\\TKart\\images\\28Bracelets.jpg',5,0,'This is an bracelet','2017-01-03 15:38:09','2017-01-03 15:38:09');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (29,'Handbags',24,220.00,'\\TKart\\images\\29HandBags.jpg',5,0,'this is an handbag','2017-01-03 15:38:54','2017-01-03 15:38:54');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (30,'Nataraja',41,10.00,'\\TKart\\images\\30download (3).jpg',1,0,'Writing faster than other pencil','2017-01-03 15:39:27','2017-01-03 15:39:27');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (31,'Ringlet',24,150.00,'\\TKart\\images\\31Ringlet.jpg',12,0,'this is an ringlet','2017-01-03 15:40:00','2017-01-03 15:40:00');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (32,'Game over',37,2300.00,'\\TKart\\images\\32images (12).jpg',4,0,'Game is over','2017-01-03 15:42:46','2017-01-03 15:42:46');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (33,'Lakme',23,55.00,'\\TKart\\images\\33Lakme Whiteton.jpg',15,0,'this is an lakme product','2017-01-03 15:43:34','2017-01-03 15:43:34');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (34,'Pampers',27,127.50,'\\TKart\\images\\34655994b.jpg',1,0,'Pampers baby ultrasoft and dry dispers','2017-01-03 15:43:43','2017-01-03 15:43:43');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (35,'Luxury vegetables ceiling lamp',34,3499.00,'\\TKart\\images\\3551MjuzMtaNL._SY700_.jpg',4,0,'Luxury Lighting','2017-01-03 15:47:44','2017-01-03 15:47:44');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (36,'Nailpaints',23,100.00,'\\TKart\\images\\36Nailpants.jpg',20,0,'this is a nailpaint','2017-01-03 15:48:42','2017-01-03 15:48:42');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (37,'lipstick',24,150.00,'\\TKart\\images\\37Lakme Lipstick.jpg',50,0,'lipstick','2017-01-03 15:49:56','2017-01-03 15:49:56');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (38,'Skirts',19,2000.00,'\\TKart\\images\\38ALine wear.jpg',10,0,'thi is a casual wear','2017-01-03 15:51:26','2017-01-03 15:51:26');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (39,'Jhonson\'s baby shampoo',27,78.20,'\\TKart\\images\\39527172a.jpg',1,0,'Happy bath with Jhonson\'s Baby Shampoo','2017-01-03 15:51:59','2017-01-03 15:51:59');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (40,'Designer Saree',19,3000.00,'\\TKart\\images\\40Saree.jpg',5,0,'this is designer saree','2017-01-03 15:52:56','2017-01-03 15:52:56');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (41,'Plazo set',19,1500.00,'\\TKart\\images\\41Plazos.jpg',10,0,'This is a plazo set','2017-01-03 15:54:40','2017-01-03 15:54:40');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (43,'Jacket',19,220.00,'\\TKart\\images\\42Shrugs.jpg',5,0,'this is a shrug5','2017-01-03 15:56:33','2017-01-03 15:56:33');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (44,'Winter wear',19,2000.00,'\\TKart\\images\\44Winter wear.jpg',3,0,'this is winter wear','2017-01-03 15:57:27','2017-01-03 15:57:27');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (46,'Jhonson\'s Baby Cream',27,78.20,'\\TKart\\images\\4647120a.jpg',1,0,'Clinically proven cream for babies','2017-01-03 18:09:15','2017-01-03 18:09:15');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (47,'heels',20,500.00,'\\TKart\\images\\47Mochi heels.jpg',6,0,'this is a footwear','2017-01-03 18:12:46','2017-01-03 18:12:46');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (49,'Shoes',20,230.00,'\\TKart\\images\\49Shoes.jpg',5,0,'this is a shoes','2017-01-03 18:14:22','2017-01-03 18:14:22');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (50,'Block heels',20,550.00,'\\TKart\\images\\50Heels.jpg',10,0,'it is a footwear','2017-01-03 18:15:06','2017-01-03 18:15:06');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (51,'Jhonson\'s Baby Soap',27,69.00,'\\TKart\\images\\513567a.jpg',1,0,'Enriched with mildness.','2017-01-03 18:15:08','2017-01-03 18:15:08');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (52,'Chappals',20,120.00,'\\TKart\\images\\52Flipflop.jpg',10,0,'This is a chappal','2017-01-03 18:18:48','2017-01-03 18:18:48');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (53,'Pigeon Baby Shampoo',27,220.15,'\\TKart\\images\\5310497a.jpg',1,0,'Perfect shampoo for baby\'s usage.','2017-01-03 18:27:18','2017-01-03 18:27:18');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (54,'Novel',36,225.00,'\\TKart\\images\\54The fault in our Stars.jpg',2,0,'it is a novel','2017-01-03 18:29:12','2017-01-03 18:29:12');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (56,'THink And Grow Rich ',36,300.00,'\\TKart\\images\\56Think and Grow Rich.jpg',5,0,'it is a novel','2017-01-03 18:30:15','2017-01-03 18:30:15');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (57,'Love Novel',36,225.00,'\\TKart\\images\\57The fault in our Stars.jpg',10,0,'it is lovestory','2017-01-03 18:31:26','2017-01-03 18:31:26');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (58,'Twilight ',36,750.00,'\\TKart\\images\\58Twilight Novel.jpg',15,0,'it ia a twilight saga story book','2017-01-03 18:32:41','2017-01-03 18:32:41');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (59,'The Hamlett',36,150.00,'\\TKart\\images\\59Hamlett.jpg',13,0,'it is a novel','2017-01-03 18:33:26','2017-01-03 18:33:26');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (60,'The Lightening Thief',36,120.00,'\\TKart\\images\\60the Lightening thief.jpg',12,0,'Ths is a novel','2017-01-03 18:34:25','2017-01-03 18:34:25');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (61,'Baby girl jacket with pant',28,899.00,'\\TKart\\images\\61unnamed.jpg',1,0,'Beautiful red color baby girl\'s jacket with pant','2017-01-03 18:34:37','2017-01-03 18:34:37');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (62,'Charlien Haries',36,140.00,'\\TKart\\images\\62Charlin Haries.jpg',8,0,'it is a novel','2017-01-03 18:36:19','2017-01-03 18:36:19');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (63,'Baby frock',28,1200.00,'\\TKart\\images\\63images.jpg',1,0,'Beautiful baby frock in black and white with hairband','2017-01-03 18:39:10','2017-01-03 18:39:10');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (64,'Guitar',39,1200.00,'\\TKart\\images\\64Guitar.jpg',15,0,'This is a guitar','2017-01-03 18:42:05','2017-01-03 18:42:05');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (65,'Drums',39,6000.00,'\\TKart\\images\\65Band.jpg',10,0,'It is an Band','2017-01-03 18:42:49','2017-01-03 18:42:49');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (67,'Samsung Headset',39,500.00,'\\TKart\\images\\67Samsung Headset.jpg',20,0,'This is an headset ','2017-01-03 18:43:55','2017-01-03 18:43:55');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (68,'Sony',39,300.00,'\\TKart\\images\\68Sony.jpg',5,0,'This is a Headset','2017-01-03 18:44:31','2017-01-03 18:44:31');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (69,'FS Mini Club for Boys',28,450.00,'\\TKart\\images\\69IMG_1483449183743.jpeg',1,0,'Perfect clothing for baby boys.','2017-01-03 18:47:44','2017-01-03 18:47:44');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (71,'Badminton',40,600.00,'\\TKart\\images\\71Badminton.jpg',10,0,'this is a Badminton','2017-01-03 18:49:31','2017-01-03 18:49:31');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (72,'Cricket Bat',40,400.00,'\\TKart\\images\\72Cricket Bat.jpg',5,0,'this is a cricket bat','2017-01-03 18:50:22','2017-01-03 18:50:22');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (73,'Football',40,500.00,'\\TKart\\images\\73Football.jpg',3,0,'this is a football','2017-01-03 18:51:10','2017-01-03 18:51:10');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (74,'Tennis',40,220.00,'\\TKart\\images\\74Tennis.jpg',4,0,'this is a tennis','2017-01-03 18:51:58','2017-01-03 18:51:58');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (79,'T-Shirt for boys',28,350.00,'\\TKart\\images\\79IMG_1483449683955.jpeg',1,0,'Full sleeves t-shirt designed for baby boys','2017-01-03 18:53:43','2017-01-03 18:53:43');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (80,'A-Line dress for girls',28,850.00,'\\TKart\\images\\80IMG_1483449886243.jpeg',1,0,'Beautiful A-Line dress for girls','2017-01-03 18:56:54','2017-01-03 18:56:54');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (81,'Pen Stand',40,50.00,'\\TKart\\images\\81Penstand.jpg',10,0,'this is a penstand','2017-01-03 18:58:00','2017-01-03 18:58:00');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (82,'Scissors',41,20.00,'\\TKart\\images\\82Scissors.jpg',5,0,'Thhs is a scissors','2017-01-03 18:58:44','2017-01-03 18:58:44');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (83,'Pencils',41,15.00,'\\TKart\\images\\83Pencils.jpg',10,0,'this is a pencils','2017-01-03 18:59:29','2017-01-03 18:59:29');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (84,'Paint Colour',41,150.00,'\\TKart\\images\\84Paintcolor.jpg',12,0,'This is a paint colour','2017-01-03 19:00:07','2017-01-03 19:00:07');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (85,'Cutter',41,20.00,'\\TKart\\images\\85cutter.jpg',12,0,'this is a cutter','2017-01-03 19:00:44','2017-01-03 19:00:44');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (86,'Sapphire off road Racing Car',26,999.00,'\\TKart\\images\\86IMG_1483450096033.jpeg',1,0,'Black color dominate any type of terrain with all new Sapphire  Off Road Racing Car','2017-01-03 19:02:57','2017-01-03 19:02:57');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (87,'Bedsheet',29,550.00,'\\TKart\\images\\87Bedsheet.jpg',10,0,'this is a bedsheet','2017-01-03 19:04:17','2017-01-03 19:04:17');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (88,'Sofa',29,1300.00,'\\TKart\\images\\88Sofa.jpg',3,0,'this is a sofa','2017-01-03 19:05:31','2017-01-03 19:05:31');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (89,'Toyhouse Educational Laptop ',26,750.00,'\\TKart\\images\\89IMG_1483450437224.jpeg',1,0,'Lots of fun with educational interactive laptop.','2017-01-03 19:06:51','2017-01-03 19:06:51');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (90,'Dinning Table',31,4000.00,'\\TKart\\images\\90Dinning table.jpg',10,0,'this is a dinning table','2017-01-03 19:10:58','2017-01-03 19:10:58');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (91,'Glass dinning Table',31,2000.00,'\\TKart\\images\\91glass dinning table.jpg',4,0,'this is a dinning table','2017-01-03 19:11:49','2017-01-03 19:11:49');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (92,'Wooden Dinning',31,5000.00,'\\TKart\\images\\92wooden dining table.jpg',15,0,'this is a wooden dinning tables','2017-01-03 19:12:36','2017-01-03 19:12:36');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (93,'Ferrari Three Wheeler Scooter',26,1799.00,'\\TKart\\images\\93IMG_1483450857852.jpeg',1,0,'Non battery operated three wheeler scooters','2017-01-03 19:14:09','2017-01-03 19:14:09');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (94,'Curtains',33,300.00,'\\TKart\\images\\94Curtains.jpg',10,0,'this is a curtain','2017-01-03 19:18:25','2017-01-03 19:18:25');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (95,'Cutions',33,500.00,'\\TKart\\images\\95Cutions.jpg',15,0,'this is a cution','2017-01-03 19:19:08','2017-01-03 19:19:08');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (96,'fabric Bedsheet',33,300.00,'\\TKart\\images\\96Fabric Bedsheet.jpg',12,0,'this is a bedsheet','2017-01-03 19:20:28','2017-01-03 19:20:28');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (97,'Silk Pillows',33,500.00,'\\TKart\\images\\97Silk Pillows.jpg',15,0,'pillow covers','2017-01-03 19:21:11','2017-01-03 19:21:11');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (98,'Hall Lamp',34,400.00,'\\TKart\\images\\98Hall Lamp.jpg',5,0,'tis is a hall lamp','2017-01-03 19:25:55','2017-01-03 19:25:55');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (99,'terrace lamp',34,5000.00,'\\TKart\\images\\99terrace lamps.jpg',1,0,'this is a terrace lamp','2017-01-03 19:26:42','2017-01-03 19:26:42');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (100,'Stairs Lights',34,1200.00,'\\TKart\\images\\100Staris lights.jpg',5,0,'this is a lightening','2017-01-03 19:27:21','2017-01-03 19:27:21');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (103,'Shinzo kid\'s toys',26,760.00,'\\TKart\\images\\101car.jpg',176,0,'toy for kids','2017-01-03 19:29:56','2017-01-03 19:29:56');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (104,'Interior',30,6000.00,'\\TKart\\images\\104Interior decoration.jpg',5,0,'thi is a interioe decoration','2017-01-03 19:33:09','2017-01-03 19:33:09');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (106,'Table decoration',30,4000.00,'\\TKart\\images\\106table decoration.jpg',40,0,'this is a table decoration','2017-01-03 19:33:55','2017-01-03 19:33:55');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (107,'wall decoration',30,7000.00,'\\TKart\\images\\107wall decoration.jpg',20,0,'this is a wall decoration','2017-01-03 19:34:38','2017-01-03 19:34:38');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (108,'Modem',42,1699.00,'\\TKart\\images\\108mdm.jpg',80,0,'Network component- modem','2017-01-03 19:35:36','2017-01-03 19:35:36');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (109,'KenStar',9,5000.00,'\\TKart\\images\\109KenStar.jpg',3,0,'this is a gyser','2017-01-03 19:37:21','2017-01-03 19:37:21');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (110,'Racold',9,1200.00,'\\TKart\\images\\110Racold.jpg',7,0,'this is a gyser','2017-01-03 19:38:05','2017-01-03 19:38:05');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (111,'N Series Routers',42,1230.00,'\\TKart\\images\\111routr.jpg',60,0,'N series Routers- DLink Wireless Router ','2017-01-03 19:39:04','2017-01-03 19:39:04');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (112,'Samsung',7,15000.00,'\\TKart\\images\\112Samsung.jpg',5,0,'this is a refregerator','2017-01-03 19:41:22','2017-01-03 19:41:22');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (113,'Belkin LAN Cable',42,139.00,'\\TKart\\images\\113lan.jpg',80,0,':Quantum Ethernet Patch Cord CAT5 RJ45 Lan Straight Cable Category 5E 5M 5 meter Rs. 115.00. In stock. ','2017-01-03 19:41:45','2017-01-03 19:41:45');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (114,'LG',7,20000.00,'\\TKart\\images\\114LG.jpg',4,0,'this is a refregerator','2017-01-03 19:41:53','2017-01-03 19:41:53');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (115,'WhirlPool',7,15000.00,'\\TKart\\images\\115WhirlPool.jpg',15,0,'this is a refregerator','2017-01-03 19:42:33','2017-01-03 19:42:33');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (116,'Sony',7,12000.00,'\\TKart\\images\\116Sony.jpg',15,0,'this is a refregerator','2017-01-03 19:43:04','2017-01-03 19:43:04');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (117,'Win 8 Data Cable Black',42,1500.00,'\\TKart\\images\\117m.jpeg',70,0,'black cable for win 8 and MAC','2017-01-03 19:45:04','2017-01-03 19:45:04');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (118,'Apple',43,1200.00,'\\TKart\\images\\118Apple.jpg',5,0,'this is a tablet','2017-01-03 19:45:51','2017-01-03 19:45:51');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (119,'Ipad',43,3000.00,'\\TKart\\images\\119Ipad.jpg',5,0,'this is a tablet','2017-01-03 19:46:57','2017-01-03 19:46:57');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (120,'Windows',43,2000.00,'\\TKart\\images\\120Windows.jpg',15,0,'this is a tablet','2017-01-03 19:47:37','2017-01-03 19:47:37');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (121,'Samsung',43,1000.00,'\\TKart\\images\\121Samsung.jpg',6,0,'this is a tablet','2017-01-03 19:48:38','2017-01-03 19:48:38');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (122,'Blackberry Solid SingleMen\'s Blazer',13,6399.00,'\\TKart\\images\\122men.jpeg',40,0,'UJBEAONBLAQ28UJL\r\nOccasion\r\nCasual\r\nSleeve\r\nFull Sleeve\r\nClosure\r\nButton\r\nFabric Care\r\nDry Clean Recommended','2017-01-03 19:50:39','2017-01-03 19:50:39');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (123,'Inkovy Solid Men\'s Hooded Black T-Shirt',13,359.00,'\\TKart\\images\\123me.jpeg',70,0,'Cool and comfortable, this solid colour t-shirt by Izinc is something you must include in your summer wardrobe. Featuring slim fit, this t-shirt is perfect for casual getaways. Made from 100% cotton, this t-shirt is not only stylish, but soft to touch as well, t-shirt will keep you dry and comfortable in summers.','2017-01-03 19:52:48','2017-01-03 19:52:48');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (124,'Hyundai',4,40000.00,'\\TKart\\images\\124Hyundai.jpg',10,0,'this is a tv','2017-01-03 19:53:15','2017-01-03 19:53:15');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (125,'LG',4,25000.00,'\\TKart\\images\\125LG.jpg',20,0,'this is a tv','2017-01-03 19:53:41','2017-01-03 19:53:41');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (127,'Samsung',4,30000.00,'\\TKart\\images\\127Samsung.jpg',14,0,'this is a tv','2017-01-03 19:54:18','2017-01-03 19:54:18');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (129,'toshiba',4,12000.00,'\\TKart\\images\\129Toshiba.jpg',12,0,'this is a tv','2017-01-03 19:54:48','2017-01-03 19:54:48');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (130,'DT Fashion Net Embroidered Semi-stitched Salwar Suit Dupatta Material',19,670.00,'\\TKart\\images\\130sit.jpeg',70,0,'Type: Semi-stitched Salwar Suit Dupatta Material\r\nFabric: Net\r\nPattern: Embroidered\r\nColor: Red\r\nPackage Contains:1 Salwar, 1 Dupatta, 1Bottom','2017-01-03 19:54:59','2017-01-03 19:54:59');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (131,'Merito Cotton Embroidered Salwar Suit ',19,999.00,'\\TKart\\images\\131su.jpeg',60,0,'Type: Semi-stitched Salwar Suit Dupatta Material, Semi-stitched Salwar Suit Material, Salwar Suit Material, Kurta & Patiyala Material\r\nFabric: Cotton\r\nPattern: Embroidered\r\nColor: Black\r\nWith Dupatta','2017-01-03 19:57:32','2017-01-03 19:57:32');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (132,'bands',15,500.00,'\\TKart\\images\\132bands.jpg',2,0,'this is a men accessorie','2017-01-03 19:59:15','2017-01-03 19:59:15');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (134,'Campus Sutra Full Sleeve Solid Women\'s Jacket',19,944.00,'\\TKart\\images\\134b.jpeg',80,0,'Regular Machine Wash, Do Not Dry Clean, Slight Color May Bleed in First Wash, Hand Wash, Machine Wash as per Tag','2017-01-03 19:59:20','2017-01-03 19:59:20');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (135,'Bracelets',15,60.00,'\\TKart\\images\\135Bracelets.jpg',6,0,'this is a men accessorie','2017-01-03 19:59:53','2017-01-03 19:59:53');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (141,'Sunglasses',15,400.00,'\\TKart\\images\\140Sunglasses.jpg',12,0,'this is a men accessorie','2017-01-03 20:00:20','2017-01-03 20:00:20');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (142,'Shoes',15,2000.00,'\\TKart\\images\\142shoes.jpg',20,0,'this is a men accessorie','2017-01-03 20:01:31','2017-01-03 20:01:31');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (143,'Ahalyaa Party Cap Sleeve Printed Women\'s Black Top',19,449.00,'\\TKart\\images\\143a.jpeg',90,0,'Boat Neck, Cap Sleeve\r\nFabric: Faux Crepe\r\nPattern: Printed\r\nType: Top','2017-01-03 20:01:32','2017-01-03 20:01:32');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (144,'Godrej 1 Ton 5 Star Split AC White  ',7,26790.00,'\\TKart\\images\\144g.jpeg',190,0,'Dust Filter\r\nAuto Restart, Sleep Mode\r\nRotary Compressor\r\nCooling Capacity: 3300 W\r\nPower Usage: 940 W','2017-01-03 20:03:59','2017-01-03 20:03:59');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (145,'Hindware Atlantic 3.0 L Instant Water Geyser ',9,2499.00,'\\TKart\\images\\145ge.jpeg',80,0,'Type: Instant\r\nVerticaly Mounted\r\nPower Consumption: 3000 W\r\nCapacity: 3.0 L\r\nW x H: 19 x 30.2 cm','2017-01-03 20:06:00','2017-01-03 20:06:00');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (147,'Kenstar 15 L Storage Water Geyser  ',9,6999.00,'\\TKart\\images\\146gey.jpeg',90,0,'Type: Storage\r\nVerticaly Mounted\r\nPower Consumption: 2000 W\r\nCapacity: 15 L\r\nW x H: 34 x 55.5 cm','2017-01-03 20:07:09','2017-01-03 20:07:09');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (149,'Formal wear',13,500.00,'\\TKart\\images\\149Formal Wear.jpg',20,0,'thi is men clothing','2017-01-03 20:08:52','2017-01-03 20:08:52');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (150,'Hindware Atlantic 25 L Storage Water Geyser',9,9269.00,'\\TKart\\images\\150geys.jpeg',50,0,'Hindware Atlantic\r\nModel Name\r\nSWH 30 M PW\r\nCapacity\r\n25 L','2017-01-03 20:09:06','2017-01-03 20:09:06');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (151,'Denim',13,6000.00,'\\TKart\\images\\151Jeans.jpg',12,0,'thi is men clothing','2017-01-03 20:09:33','2017-01-03 20:09:33');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (152,'Winter wear',13,1200.00,'\\TKart\\images\\152winter wear.jpg',5,0,'thina men clothing','2017-01-03 20:10:15','2017-01-03 20:10:15');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (153,'FTC Bazar Girls Layered White Dress',25,403.00,'\\TKart\\images\\153ba.jpeg',75,0,'Length: Midi/Knee Length\r\nFabric: net\r\nOccasion: Party','2017-01-03 20:11:37','2017-01-03 20:11:37');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (154,'Bella Moda Gathered For Girls  (Blue Sleeveless)',25,492.00,'\\TKart\\images\\154f.jpeg',65,0,'Fabric: Cotton\r\nColor: Blue\r\nCharacter: No Character\r\nType: Gathered\r\nMidi/Knee Length Dress','2017-01-03 20:14:19','2017-01-03 20:14:19');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (155,'Housefull Metal Dining Set',31,15350.00,'\\TKart\\images\\155dining.jpeg',76,0,'Wrought Iron\r\n6 Seater\r\nKnock Down\r\nStorage Included\r\nUpholstery Included\r\nW x H x D: 1000 mm x 1000 mm x 1000 mm','2017-01-03 20:16:29','2017-01-03 20:16:29');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (156,'Deoderant',18,400.00,'\\TKart\\images\\156Deoderant.jpg',30,0,'this is a men care','2017-01-03 20:17:33','2017-01-03 20:17:33');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (157,'Durian NEON Glass Dining Set',31,13520.00,'\\TKart\\images\\157din.jpeg',80,0,'Tempered Glass\r\n4 Seater\r\nKnock Down\r\nUpholstery Included\r\nW x H x D: 900 mm x 750 mm x 900 mm','2017-01-03 20:18:30','2017-01-03 20:18:30');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (158,'The Attic Solid Wood Dining Set',31,28999.00,'\\TKart\\images\\158dini.jpeg',76,0,'Rosewood (Sheesham)\r\n6 Seater\r\nDIY(Do-It-Yourself)\r\nW x H x D: 900 mm x 750 mm x 1600 mm','2017-01-03 20:19:58','2017-01-03 20:19:58');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (159,'Nivea Gel',18,150.00,'\\TKart\\images\\159Nivea Gel.jpg',4,0,'this is a men care','2017-01-03 20:22:19','2017-01-03 20:22:19');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (160,'Xylys 9295TM01 Analog Watch',14,38000.00,'\\TKart\\images\\160wt.jpeg',50,0,'Water Resistant\r\nDisplay Type: Analog\r\nStrap: Silver, Stainless Steel\r\nChronograph','2017-01-03 20:22:39','2017-01-03 20:22:39');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (161,'Trimmer',18,500.00,'\\TKart\\images\\161Trimmer.jpg',40,0,'this is a men care','2017-01-03 20:23:10','2017-01-03 20:23:10');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (162,'Perfume',18,600.00,'\\TKart\\images\\162Perfume.jpg',8,0,'this is a men care','2017-01-03 20:23:45','2017-01-03 20:23:45');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (163,'Swiss Eagle SE-9062-44 Analog Watch ',14,25543.00,'\\TKart\\images\\163wac.jpeg',20,0,'Display Type: Analog\r\nStrap: Multicolor','2017-01-03 20:24:11','2017-01-03 20:24:11');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (165,'Nivea men',18,515.00,'\\TKart\\images\\165Nivea men.jpg',5,0,'this is a men care','2017-01-03 20:24:32','2017-01-03 20:24:32');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (166,'Victorinox 241659 Basic Analog Watch',14,34590.00,'\\TKart\\images\\166wa1.jpeg',50,0,'Water Resistant\r\nDisplay Type: Analog\r\nStrap: Brown\r\nChronograph, Scratch Resistant','2017-01-03 20:25:22','2017-01-03 20:25:22');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (167,'Xylys NF40005SM01 Analog Watch',14,32500.00,'\\TKart\\images\\167wa2.jpeg',60,0,'Water Resistant (100 m)\r\nDisplay Type: Analog\r\nStrap: Silver','2017-01-03 20:27:19','2017-01-03 20:27:19');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (169,'Victorinox 241512-1 Basic Analog Watch',21,27686.00,'\\TKart\\images\\169we1.jpeg',60,0,'Water Resistant\r\nDisplay Type: Analog\r\nStrap: Silver\r\nScratch Resistant','2017-01-03 20:29:58','2017-01-03 20:29:58');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (170,'Fastrack',15,5000.00,'\\TKart\\images\\170fastrack.jpg',5,0,'this is branded watch','2017-01-03 20:30:07','2017-01-03 20:30:07');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (171,'Sonata',14,8000.00,'\\TKart\\images\\171Sonata.jpg',6,0,'this is branded watch','2017-01-03 20:30:34','2017-01-03 20:30:34');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (174,'Fastrack 6148SM01C Watch ',21,1995.00,'\\TKart\\images\\174me3.jpeg',20,0,'Stainless steel strap','2017-01-03 20:31:39','2017-01-03 20:31:39');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (176,'Titan',14,2000.00,'\\TKart\\images\\176Titan.jpg',3,0,'this is branded watch','2017-01-03 20:32:15','2017-01-03 20:32:15');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (177,'5 liter Geyser',8,21000.00,'\\TKart\\images\\1775 liter geyser.jpg',3,0,'coil is sustainable','2017-01-04 14:35:17','2017-01-04 14:35:17');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (178,'Samsung',7,22000.00,'\\TKart\\images\\178double door refrigerator.jpg',4,0,'This is a refrigerator','2017-01-04 14:37:58','2017-01-04 14:37:58');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (179,'LG',11,1000.00,'\\TKart\\images\\179emergency light.jpg',8,0,'This is a Emergency Light','2017-01-04 14:39:46','2017-01-04 14:39:46');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (180,'Jmug',11,500.00,'\\TKart\\images\\180coffee mug.jpg',7,0,'This is a Coffee Mug','2017-01-04 14:41:43','2017-01-04 14:41:43');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (182,'HeadFirst Java',36,300.00,'\\TKart\\images\\182academic.jpg',8,0,'this is a head first java book','2017-01-04 14:59:34','2017-01-04 14:59:34');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (184,'Autobiography sania Mirza',37,808.00,'\\TKart\\images\\184badminton book.jpg',9,0,'this is a autobiography of sania mirza','2017-01-04 15:04:46','2017-01-04 15:04:46');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (185,' A Tribute Legend',37,500.00,'\\TKart\\images\\185cricket book.jpg',8,0,' sachin autobiography','2017-01-04 15:09:03','2017-01-04 15:09:03');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (186,'btown music',39,852.00,'\\TKart\\images\\186bollywood music.jpg',89,0,'bollywood music','2017-01-04 15:10:07','2017-01-04 15:10:07');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (187,'literature',36,200.00,'\\TKart\\images\\187literature.jpg',8,0,'this is a literature book','2017-01-04 15:11:37','2017-01-04 15:11:37');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (189,'Babybath care',27,600.00,'\\TKart\\images\\189baby bath skin care.jpg',7,0,'this is combo baby bath care shampooos','2017-01-04 15:20:44','2017-01-04 15:20:44');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (190,'Baby Bedding',27,600.00,'\\TKart\\images\\190baby bedding.jpg',4,0,'This is a baby bedding','2017-01-04 15:21:56','2017-01-04 15:21:56');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (192,'Baby Health Care',27,900.00,'\\TKart\\images\\192baby health and safety kit.jpg',8,0,'This is a Baby Health Care','2017-01-04 15:24:23','2017-01-04 15:24:23');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (193,'Baby Grooming',27,10000.00,'\\TKart\\images\\193baby_grooming.jpg',9,0,'This is a Baby Grooming','2017-01-04 15:25:28','2017-01-04 15:25:28');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (194,'Bed Spread',30,1900.00,'\\TKart\\images\\194bed sheets.jpg',9,0,'This is a Bed Spread','2017-01-04 15:26:53','2017-01-04 15:26:53');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (196,'Nestle Coffee',32,30.00,'\\TKart\\images\\196coffee.jpg',12,0,'thhis is a kitchen stuff','2017-01-04 15:27:14','2017-01-04 15:27:14');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (197,'DietCoke',32,150.00,'\\TKart\\images\\197Diet.jpg',6,0,'this is a kitchen storage','2017-01-04 15:28:07','2017-01-04 15:28:07');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (198,'Kurlon',29,3500.00,'\\TKart\\images\\198beds.jpg',4,0,'This is a Kurlon Bed','2017-01-04 15:28:08','2017-01-04 15:28:08');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (199,'Fragrance',23,150.00,'\\TKart\\images\\199Fragnance.jpg',6,0,'This is a beauty Product','2017-01-04 15:29:09','2017-01-04 15:29:09');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (200,'Woodland',15,500.00,'\\TKart\\images\\200belts.jpg',5,0,'This is a Woodland Brand','2017-01-04 15:29:17','2017-01-04 15:29:17');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (201,'Dove Care',23,220.00,'\\TKart\\images\\201Hair care.jpg',5,0,'This is a beauty care','2017-01-04 15:30:01','2017-01-04 15:30:01');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (202,'TAJ',32,55.00,'\\TKart\\images\\202tea.jpg',50,0,'This is a kitchen stuff','2017-01-04 15:30:43','2017-01-04 15:30:43');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (203,'Tupperwear Bottles',10,100.00,'\\TKart\\images\\203bottles.jpg',6,0,'This is a Tupperwear Bottles','2017-01-04 15:31:07','2017-01-04 15:31:07');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (204,'Cannon',5,6000.00,'\\TKart\\images\\204Cannon.jpg',1,0,'This is Camera','2017-01-04 15:31:34','2017-01-04 15:31:34');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (205,'Gloves',13,130.00,'\\TKart\\images\\205gloves.jpg',40,0,'This is a stuff','2017-01-04 15:32:16','2017-01-04 15:32:16');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (206,'Miltry Jacket',13,500.00,'\\TKart\\images\\206boys clothing.jpg',8,0,'This is a military Jacket','2017-01-04 15:32:35','2017-01-04 15:32:35');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (207,'Helmets',18,300.00,'\\TKart\\images\\207Helmets.jpg',10,0,'This is a Personal Care','2017-01-04 15:33:12','2017-01-04 15:33:12');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (208,'Loafers',12,1800.00,'\\TKart\\images\\208casual shoes.jpg',8,0,'This is a Loafers','2017-01-04 15:33:52','2017-01-04 15:33:52');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (209,'camera lenses',44,6000.00,'\\TKart\\images\\209Lenses.jpg',6,0,'This is a camera stuff','2017-01-04 15:34:27','2017-01-04 15:34:27');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (210,'Wall Clock',11,600.00,'\\TKart\\images\\210clock.jpg',6,0,'This is a Wall Clock','2017-01-04 15:35:10','2017-01-04 15:35:10');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (211,'Printers',42,12000.00,'\\TKart\\images\\211printers.jpg',7,0,'This is a Personal Care\r\n\r\n','2017-01-04 15:36:03','2017-01-04 15:36:03');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (212,'Crt ',11,10000.00,'\\TKart\\images\\212crt tv.jpg',2,0,'This is a CRT tv','2017-01-04 15:36:25','2017-01-04 15:36:25');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (213,'Sandisk',42,180.00,'\\TKart\\images\\213pendrive.jpg',10,0,'This is a pendrive','2017-01-04 15:36:50','2017-01-04 15:36:50');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (214,'Blue Curtains',11,1700.00,'\\TKart\\images\\214curtains.jpg',9,0,'This is a Blue Curtain','2017-01-04 15:37:36','2017-01-04 15:37:36');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (215,'Samsung Memory',42,120.00,'\\TKart\\images\\215Memorycard.jpg',10,0,'This is a memory card','2017-01-04 15:38:27','2017-01-04 15:38:27');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (216,'Personal Dairy',24,500.00,'\\TKart\\images\\216dairy.jpg',8,0,'This is a Personal Dairy','2017-01-04 15:39:03','2017-01-04 15:39:03');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (218,'Decorative Lamps',11,70000.00,'\\TKart\\images\\218decorative lamps.jpg',5,0,'This is a decorative Lamp','2017-01-04 15:40:24','2017-01-04 15:40:24');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (219,'Slings',23,450.00,'\\TKart\\images\\219sling bags.jpg',5,0,'This is a sling Bag','2017-01-04 15:41:18','2017-01-04 15:41:18');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (220,'Clutches',24,1500.00,'\\TKart\\images\\220clutches.jpg',12,0,'This is a clutch','2017-01-04 15:42:08','2017-01-04 15:42:08');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (221,'DSLR',11,2000.00,'\\TKart\\images\\221dslr camera.jpg',5,0,'This is a DSLR Camera','2017-01-04 15:42:35','2017-01-04 15:42:35');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (222,'Fish Aquarium',30,2500.00,'\\TKart\\images\\222aqu.jpg',3,0,'This is a home stuff','2017-01-04 15:43:40','2017-01-04 15:43:40');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (223,'Educational Toys',26,1700.00,'\\TKart\\images\\223educational toys.jpg',8,0,'This is a Educational Toys','2017-01-04 15:44:02','2017-01-04 15:44:02');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (224,'Cooking gas',11,5000.00,'\\TKart\\images\\224kitchen.jpg',15,0,'This is a kitchen stuff','2017-01-04 15:44:39','2017-01-04 15:44:39');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (225,'Lehenga',19,1800.00,'\\TKart\\images\\225ethnic wear.jpg',8,0,'This is a ethnic wear','2017-01-04 15:46:01','2017-01-04 15:46:01');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (226,'Power Bank',42,1200.00,'\\TKart\\images\\226power bank.jpg',6,0,'This is a a Power bank','2017-01-04 15:46:19','2017-01-04 15:46:19');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (227,'Fastrack',21,1900.00,'\\TKart\\images\\227fastrack watch for women.jpg',8,0,'This is a fastrack Watch','2017-01-04 15:46:54','2017-01-04 15:46:54');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (228,'Screen Pad',1,250.00,'\\TKart\\images\\228Screen protectors.jpg',10,0,'This is a Mobile Protector','2017-01-04 15:47:35','2017-01-04 15:47:35');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (229,'Ipad',43,3000.00,'\\TKart\\images\\229tablet Acessories.jpg',30,0,'This is a Tablet','2017-01-04 15:48:24','2017-01-04 15:48:24');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (230,'Fastrack',12,1800.00,'\\TKart\\images\\230fastrack watch for men.jpg',8,0,'This is a Fastrack Watch','2017-01-04 15:48:52','2017-01-04 15:48:52');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (231,'Mobile Back Covers',2,150.00,'\\TKart\\images\\231case and covers.jpg',50,0,'This is a Mobile Cover','2017-01-04 15:49:23','2017-01-04 15:49:23');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (232,'Flask',11,1900.00,'\\TKart\\images\\232flask.jpg',7,0,'This is a Flask','2017-01-04 15:49:58','2017-01-04 15:49:58');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (233,'Woodland',12,1500.00,'\\TKart\\images\\233Formal.jpg',15,0,'This is a Men Footwear\r\n','2017-01-04 15:50:26','2017-01-04 15:50:26');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (234,'Flat ',20,1200.00,'\\TKart\\images\\234flat slippers.jpg',5,0,'This is a Flat Slipper','2017-01-04 15:50:54','2017-01-04 15:50:54');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (235,'Loafers',12,3000.00,'\\TKart\\images\\235Loafers.jpg',5,0,'This is a Footer','2017-01-04 15:51:17','2017-01-04 15:51:17');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (236,'Sneakers',12,7000.00,'\\TKart\\images\\236sneakers.jpg',18,0,'This is a Footer','2017-01-04 15:51:57','2017-01-04 15:51:57');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (237,'Lionell Messi',40,1900.00,'\\TKart\\images\\237football book.jpg',10,0,'This is a Football Book','2017-01-04 15:52:19','2017-01-04 15:52:19');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (238,'Mochi',20,3000.00,'\\TKart\\images\\238ShoesWomen.jpg',14,0,'This is a footwear','2017-01-04 15:52:39','2017-01-04 15:52:39');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (239,'Hand Bags',24,1000.00,'\\TKart\\images\\239hand bags.jpg',8,0,'This is a Hand Bags','2017-01-04 15:53:42','2017-01-04 15:53:42');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (240,'Heels',20,500.00,'\\TKart\\images\\240heels.jpg',8,0,'This is a Heel Slipper','2017-01-04 15:55:02','2017-01-04 15:55:02');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (241,'Nike',12,4000.00,'\\TKart\\images\\241ShoesMen.jpg',15,0,'This is a footwear','2017-01-04 18:19:04','2017-01-04 18:19:04');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (242,'Fastrack',14,2000.00,'\\TKart\\images\\242wm.jpg',12,0,'This is Watch','2017-01-04 18:20:37','2017-01-04 18:20:37');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (243,'Sonata Clock',30,1200.00,'\\TKart\\images\\243wall clock.jpg',2,0,'This is a clock','2017-01-04 18:21:34','2017-01-04 18:21:34');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (244,'Anklet',24,1500.00,'\\TKart\\images\\244Anklets.jpg',12,0,'This is a anklet','2017-01-04 18:22:44','2017-01-04 18:22:44');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (245,'Bracelets',24,150.00,'\\TKart\\images\\245bracelets.jpg',10,0,'This is a bracelet','2017-01-04 18:23:48','2017-01-04 18:23:48');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (246,'Dell inspiron',3,47000.00,'\\TKart\\images\\246dell1.jpg',10,0,'This is a Laptop','2017-01-04 18:24:43','2017-01-04 18:24:43');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (247,'Dell inspiron',3,47000.00,'\\TKart\\images\\246dell1.jpg',10,0,'This is a Laptop','2017-01-04 18:24:43','2017-01-04 18:24:43');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (248,'RED HEELS',20,500.00,'\\TKart\\images\\248download (5).jpg',15,0,'This is a FOOTWEAR','2017-01-04 19:07:59','2017-01-04 18:26:29');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (249,'Adidas',12,6000.00,'\\TKart\\images\\249casual shoes.jpg',5,0,'this is adidas shoes','2017-01-04 18:28:20','2017-01-04 18:28:20');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (250,'motivational videos',45,800.00,'\\TKart\\images\\250All videos.png',2,0,'This is an entertaintment','2017-01-04 18:28:39','2017-01-04 18:28:39');
INSERT INTO `product_details` (`product_id`,`product_name`,`catagory_id`,`price`,`path`,`quantity`,`sold`,`technical_details`,`modify_date`,`added_date`) VALUES (251,'Earings',22,200.00,'\\TKart\\images\\251Earings.jpg',5,0,'This is an earring','2017-01-04 18:30:42','2017-01-04 18:30:42');




INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('1',79,'2012-12-12','2012-12-18','2017-01-03 00:51:44','2017-01-03 00:51:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('10',5,'2017-01-03','2017-01-20','2017-01-03 15:04:15','2017-01-03 15:04:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('100',0,'2017-01-03','2017-01-03','2017-01-03 19:27:21','2017-01-03 19:27:21');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('101',15,'2012-12-12','2012-12-18','2017-01-03 19:29:57','2017-01-03 19:27:57');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('104',0,'2017-01-03','2017-01-03','2017-01-03 19:33:09','2017-01-03 19:33:09');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('105',0,'2017-01-03','2017-01-03','2017-01-03 19:33:09','2017-01-03 19:33:09');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('106',0,'2017-01-03','2017-01-03','2017-01-03 19:33:55','2017-01-03 19:33:55');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('107',0,'2017-01-03','2017-01-03','2017-01-03 19:34:38','2017-01-03 19:34:38');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('108',16,'2017-01-03','2017-02-07','2017-01-03 19:35:36','2017-01-03 19:35:36');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('109',0,'2017-01-03','2017-01-03','2017-01-03 19:37:22','2017-01-03 19:37:22');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('11',25,'2017-01-03','2017-02-03','2017-01-03 15:05:38','2017-01-03 15:05:38');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('110',0,'2017-01-03','2017-01-03','2017-01-03 19:38:05','2017-01-03 19:38:05');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('111',15,'2017-01-03','2017-02-22','2017-01-03 19:39:04','2017-01-03 19:39:04');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('112',0,'2017-01-03','2017-01-03','2017-01-03 19:41:22','2017-01-03 19:41:22');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('113',12,'2017-01-03','2017-02-23','2017-01-03 19:41:45','2017-01-03 19:41:45');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('114',0,'2017-01-03','2017-01-03','2017-01-03 19:41:53','2017-01-03 19:41:53');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('115',0,'2017-01-03','2017-01-03','2017-01-03 19:42:33','2017-01-03 19:42:33');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('116',0,'2017-01-03','2017-01-03','2017-01-03 19:43:04','2017-01-03 19:43:04');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('117',10,'2017-01-03','2017-01-05','2017-01-03 19:45:04','2017-01-03 19:45:04');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('118',0,'2017-01-03','2017-01-03','2017-01-03 19:45:51','2017-01-03 19:45:51');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('119',0,'2017-01-03','2017-01-03','2017-01-03 19:46:57','2017-01-03 19:46:57');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('12',6,'2017-01-03','2017-01-19','2017-01-03 15:08:10','2017-01-03 15:08:10');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('120',0,'2017-01-03','2017-01-03','2017-01-03 19:47:37','2017-01-03 19:47:37');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('121',0,'2017-01-03','2017-01-03','2017-01-03 19:48:38','2017-01-03 19:48:38');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('122',0,'2017-01-03','2017-01-03','2017-01-03 19:50:39','2017-01-03 19:50:39');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('123',0,'2017-01-03','2017-01-03','2017-01-03 19:52:48','2017-01-03 19:52:48');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('124',0,'2017-01-03','2017-01-03','2017-01-03 19:53:15','2017-01-03 19:53:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('125',0,'2017-01-03','2017-01-03','2017-01-03 19:53:41','2017-01-03 19:53:41');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('126',0,'2017-01-03','2017-01-03','2017-01-03 19:53:41','2017-01-03 19:53:41');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('127',0,'2017-01-03','2017-01-03','2017-01-03 19:54:18','2017-01-03 19:54:18');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('128',0,'2017-01-03','2017-01-03','2017-01-03 19:54:48','2017-01-03 19:54:48');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('129',0,'2017-01-03','2017-01-03','2017-01-03 19:54:48','2017-01-03 19:54:48');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('13',8,'2017-01-03','2017-01-27','2017-01-03 15:09:35','2017-01-03 15:09:35');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('130',0,'2017-01-03','2017-01-03','2017-01-03 19:54:59','2017-01-03 19:54:59');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('131',0,'2017-01-03','2017-01-03','2017-01-03 19:57:33','2017-01-03 19:57:33');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('132',0,'2017-01-03','2017-01-03','2017-01-03 19:59:16','2017-01-03 19:59:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('133',0,'2017-01-03','2017-01-03','2017-01-03 19:59:16','2017-01-03 19:59:16');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('134',0,'2017-01-03','2017-01-03','2017-01-03 19:59:20','2017-01-03 19:59:20');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('135',0,'2017-01-03','2017-01-03','2017-01-03 19:59:53','2017-01-03 19:59:53');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('137',0,'2017-01-03','2017-01-03','2017-01-03 20:00:19','2017-01-03 20:00:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('138',0,'2017-01-03','2017-01-03','2017-01-03 20:00:20','2017-01-03 20:00:20');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('139',0,'2017-01-03','2017-01-03','2017-01-03 20:00:20','2017-01-03 20:00:20');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('14',10,'2017-01-03','2017-02-03','2017-01-03 15:13:24','2017-01-03 15:13:24');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('140',0,'2017-01-03','2017-01-03','2017-01-03 20:00:20','2017-01-03 20:00:20');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('141',0,'2017-01-03','2017-01-03','2017-01-03 20:00:20','2017-01-03 20:00:20');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('142',0,'2017-01-03','2017-01-03','2017-01-03 20:01:31','2017-01-03 20:01:31');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('143',0,'2017-01-03','2017-01-03','2017-01-03 20:01:32','2017-01-03 20:01:32');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('144',0,'2017-01-03','2017-01-03','2017-01-03 20:03:59','2017-01-03 20:03:59');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('145',0,'2017-01-03','2017-01-03','2017-01-03 20:06:00','2017-01-03 20:06:00');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('146',0,'2017-01-03','2017-01-03','2017-01-03 20:06:26','2017-01-03 20:06:26');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('148',0,'2017-01-03','2017-01-03','2017-01-03 20:07:39','2017-01-03 20:07:39');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('149',0,'2017-01-03','2017-01-03','2017-01-03 20:08:52','2017-01-03 20:08:52');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('15',6,'2017-01-03','2017-01-27','2017-01-03 15:14:01','2017-01-03 15:14:01');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('150',0,'2017-01-03','2017-01-03','2017-01-03 20:09:07','2017-01-03 20:09:07');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('151',0,'2017-01-03','2017-01-03','2017-01-03 20:09:33','2017-01-03 20:09:33');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('152',0,'2017-01-03','2017-01-03','2017-01-03 20:10:15','2017-01-03 20:10:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('153',0,'2017-01-03','2017-01-03','2017-01-03 20:11:37','2017-01-03 20:11:37');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('154',0,'2017-01-03','2017-01-03','2017-01-03 20:14:19','2017-01-03 20:14:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('155',0,'2017-01-03','2017-01-03','2017-01-03 20:16:29','2017-01-03 20:16:29');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('156',0,'2017-01-03','2017-01-03','2017-01-03 20:17:33','2017-01-03 20:17:33');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('157',0,'2017-01-03','2017-01-03','2017-01-03 20:18:30','2017-01-03 20:18:30');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('158',0,'2017-01-03','2017-01-03','2017-01-03 20:19:58','2017-01-03 20:19:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('159',0,'2017-01-03','2017-01-03','2017-01-03 20:22:19','2017-01-03 20:22:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('16',4,'2017-01-03','2017-01-25','2017-01-03 15:16:04','2017-01-03 15:16:04');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('160',0,'2017-01-03','2017-01-03','2017-01-03 20:22:39','2017-01-03 20:22:39');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('161',0,'2017-01-03','2017-01-03','2017-01-03 20:23:10','2017-01-03 20:23:10');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('162',0,'2017-01-03','2017-01-03','2017-01-03 20:23:45','2017-01-03 20:23:45');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('163',0,'2017-01-03','2017-01-03','2017-01-03 20:24:11','2017-01-03 20:24:11');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('164',0,'2017-01-03','2017-01-03','2017-01-03 20:24:32','2017-01-03 20:24:32');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('165',0,'2017-01-03','2017-01-03','2017-01-03 20:24:32','2017-01-03 20:24:32');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('166',0,'2017-01-03','2017-01-03','2017-01-03 20:25:22','2017-01-03 20:25:22');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('167',0,'2017-01-03','2017-01-03','2017-01-03 20:27:19','2017-01-03 20:27:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('168',0,'2017-01-03','2017-01-03','2017-01-03 20:28:33','2017-01-03 20:28:33');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('169',0,'2017-01-03','2017-01-03','2017-01-03 20:29:58','2017-01-03 20:29:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('17',4,'2017-01-14','2017-01-27','2017-01-03 15:17:38','2017-01-03 15:17:38');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('170',0,'2017-01-03','2017-01-03','2017-01-03 20:30:07','2017-01-03 20:30:07');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('171',0,'2017-01-03','2017-01-03','2017-01-03 20:30:35','2017-01-03 20:30:35');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('172',0,'2017-01-03','2017-01-03','2017-01-03 20:30:35','2017-01-03 20:30:35');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('173',0,'2017-01-03','2017-01-03','2017-01-03 20:30:38','2017-01-03 20:30:38');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('174',0,'2017-01-03','2017-01-03','2017-01-03 20:31:39','2017-01-03 20:31:39');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('175',0,'2017-01-03','2017-01-03','2017-01-03 20:31:44','2017-01-03 20:31:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('176',0,'2017-01-03','2017-01-03','2017-01-03 20:32:15','2017-01-03 20:32:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('177',15,'2017-01-04','2017-01-27','2017-01-04 14:35:17','2017-01-04 14:35:17');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('178',18,'2017-01-12','2017-01-19','2017-01-04 14:37:58','2017-01-04 14:37:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('179',18,'2017-01-04','2017-01-20','2017-01-04 14:39:46','2017-01-04 14:39:46');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('18',5,'2017-01-03','2017-02-03','2017-01-03 15:18:49','2017-01-03 15:18:49');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('180',7,'2017-01-05','2017-01-27','2017-01-04 14:41:43','2017-01-04 14:41:43');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('181',11,'2017-01-05','2017-01-14','2017-01-04 14:59:34','2017-01-04 14:59:34');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('182',11,'2017-01-05','2017-01-14','2017-01-04 14:59:34','2017-01-04 14:59:34');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('183',50,'2017-01-13','2017-01-20','2017-01-04 15:02:25','2017-01-04 15:02:25');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('184',9,'2017-01-14','2017-02-08','2017-01-04 15:04:46','2017-01-04 15:04:46');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('185',15,'2017-01-04','2017-02-03','2017-01-04 15:09:04','2017-01-04 15:09:04');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('186',58,'2017-01-13','2017-01-20','2017-01-04 15:10:07','2017-01-04 15:10:07');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('187',85,'2017-01-07','2017-01-13','2017-01-04 15:11:38','2017-01-04 15:11:38');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('188',63,'2017-01-06','2017-01-07','2017-01-04 15:13:25','2017-01-04 15:13:25');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('189',36,'2017-01-19','2017-01-13','2017-01-04 15:20:44','2017-01-04 15:20:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('19',5,'2017-01-01','2017-01-04','2017-01-03 15:24:37','2017-01-03 15:24:37');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('190',7,'2017-01-12','2017-01-26','2017-01-04 15:21:56','2017-01-04 15:21:56');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('191',5,'2017-01-06','2017-01-28','2017-01-04 15:23:11','2017-01-04 15:23:11');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('192',8,'2017-01-05','2017-01-20','2017-01-04 15:24:23','2017-01-04 15:24:23');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('193',17,'2017-01-12','2017-01-21','2017-01-04 15:25:28','2017-01-04 15:25:28');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('194',6,'2017-01-05','2017-01-20','2017-01-04 15:26:53','2017-01-04 15:26:53');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('195',0,'2017-01-04','2017-01-04','2017-01-04 15:27:14','2017-01-04 15:27:14');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('196',0,'2017-01-04','2017-01-04','2017-01-04 15:27:14','2017-01-04 15:27:14');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('197',0,'2017-01-04','2017-01-04','2017-01-04 15:28:07','2017-01-04 15:28:07');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('198',7,'2017-01-12','2017-01-26','2017-01-04 15:28:08','2017-01-04 15:28:08');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('199',0,'2017-01-04','2017-01-04','2017-01-04 15:29:09','2017-01-04 15:29:09');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('2',89,'2017-01-03','2017-01-03','2017-01-03 00:52:51','2017-01-03 00:52:31');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('20',6,'2017-01-05','2017-01-14','2017-01-03 15:26:41','2017-01-03 15:25:28');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('200',5,'2017-01-05','2017-01-20','2017-01-04 15:29:17','2017-01-04 15:29:17');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('201',0,'2017-01-04','2017-01-04','2017-01-04 15:30:01','2017-01-04 15:30:01');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('202',0,'2017-01-04','2017-01-04','2017-01-04 15:30:43','2017-01-04 15:30:43');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('203',7,'2017-01-05','2017-01-20','2017-01-04 15:31:07','2017-01-04 15:31:07');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('204',0,'2017-01-04','2017-01-04','2017-01-04 15:31:34','2017-01-04 15:31:34');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('205',0,'2017-01-04','2017-01-04','2017-01-04 15:32:16','2017-01-04 15:32:16');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('206',6,'2017-01-12','2017-01-20','2017-01-04 15:32:35','2017-01-04 15:32:35');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('207',0,'2017-01-04','2017-01-04','2017-01-04 15:33:12','2017-01-04 15:33:12');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('208',7,'2017-01-12','2017-01-27','2017-01-04 15:33:52','2017-01-04 15:33:52');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('209',0,'2017-01-04','2017-01-04','2017-01-04 15:34:27','2017-01-04 15:34:27');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('21',6,'2017-01-05','2017-01-14','2017-01-03 15:26:42','2017-01-03 15:26:42');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('210',7,'2017-01-12','2017-01-13','2017-01-04 15:35:10','2017-01-04 15:35:10');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('211',0,'2017-01-04','2017-01-04','2017-01-04 15:36:03','2017-01-04 15:36:03');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('212',17,'2017-01-12','2017-01-26','2017-01-04 15:36:25','2017-01-04 15:36:25');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('213',0,'2017-01-04','2017-01-04','2017-01-04 15:36:50','2017-01-04 15:36:50');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('214',7,'2017-01-05','2017-01-13','2017-01-04 15:37:36','2017-01-04 15:37:36');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('215',0,'2017-01-04','2017-01-04','2017-01-04 15:38:27','2017-01-04 15:38:27');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('216',7,'2017-01-05','2017-01-20','2017-01-04 15:39:03','2017-01-04 15:39:03');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('217',0,'2017-01-04','2017-01-04','2017-01-04 15:40:19','2017-01-04 15:40:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('218',8,'2017-01-05','2017-01-13','2017-01-04 15:40:25','2017-01-04 15:40:25');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('219',0,'2017-01-04','2017-01-04','2017-01-04 15:41:18','2017-01-04 15:41:18');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('22',0,'2017-01-03','2017-01-03','2017-01-03 15:28:08','2017-01-03 15:28:08');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('220',0,'2017-01-04','2017-01-04','2017-01-04 15:42:08','2017-01-04 15:42:08');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('221',9,'2017-01-12','2017-01-19','2017-01-04 15:42:35','2017-01-04 15:42:35');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('222',0,'2017-01-04','2017-01-04','2017-01-04 15:43:41','2017-01-04 15:43:41');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('223',17,'2017-01-18','2017-01-21','2017-01-04 15:44:03','2017-01-04 15:44:03');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('224',0,'2017-01-04','2017-01-04','2017-01-04 15:44:39','2017-01-04 15:44:39');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('225',7,'2017-01-20','2017-01-26','2017-01-04 15:46:01','2017-01-04 15:46:01');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('226',20,'2017-01-03','2017-01-05','2017-01-04 15:46:19','2017-01-04 15:46:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('227',10,'2017-01-18','2017-01-27','2017-01-04 15:46:54','2017-01-04 15:46:54');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('228',25,'2017-01-11','2017-01-15','2017-01-04 15:47:35','2017-01-04 15:47:35');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('229',25,'2017-01-04','2017-01-04','2017-01-04 15:48:24','2017-01-04 15:48:24');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('23',5,'2017-01-03','2017-01-27','2017-01-03 15:28:29','2017-01-03 15:28:28');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('230',17,'2017-01-20','2017-01-28','2017-01-04 15:48:52','2017-01-04 15:48:52');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('231',0,'2017-01-04','2017-01-04','2017-01-04 15:49:23','2017-01-04 15:49:23');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('232',6,'2017-01-12','2017-01-27','2017-01-04 15:49:58','2017-01-04 15:49:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('233',0,'2017-01-04','2017-01-04','2017-01-04 15:50:26','2017-01-04 15:50:26');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('234',7,'2017-01-19','2017-01-28','2017-01-04 15:50:54','2017-01-04 15:50:54');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('235',0,'2017-01-04','2017-01-04','2017-01-04 15:51:17','2017-01-04 15:51:17');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('236',0,'2017-01-04','2017-01-04','2017-01-04 15:51:57','2017-01-04 15:51:57');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('237',8,'2017-01-11','2017-01-20','2017-01-04 15:52:19','2017-01-04 15:52:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('238',0,'2017-01-04','2017-01-04','2017-01-04 15:52:39','2017-01-04 15:52:39');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('239',7,'2017-01-12','2017-01-26','2017-01-04 15:53:42','2017-01-04 15:53:42');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('24',30,'2017-01-04','2017-01-12','2017-01-03 15:30:11','2017-01-03 15:29:31');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('240',7,'2017-01-12','2017-01-20','2017-01-04 15:55:02','2017-01-04 15:55:02');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('241',0,'2017-01-04','2017-01-04','2017-01-04 18:19:04','2017-01-04 18:19:04');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('242',0,'2017-01-04','2017-01-04','2017-01-04 18:20:37','2017-01-04 18:20:37');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('243',0,'2017-01-04','2017-01-04','2017-01-04 18:21:34','2017-01-04 18:21:34');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('244',0,'2017-01-04','2017-01-04','2017-01-04 18:22:44','2017-01-04 18:22:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('245',0,'2017-01-04','2017-01-04','2017-01-04 18:23:48','2017-01-04 18:23:48');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('246',0,'2017-01-04','2017-01-04','2017-01-04 18:24:43','2017-01-04 18:24:43');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('248',0,'2017-01-04','2017-01-04','2017-01-04 18:26:29','2017-01-04 18:26:29');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('249',20,'2017-01-07','2017-01-08','2017-01-04 18:28:20','2017-01-04 18:28:20');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('25',5,'2017-01-03','2017-01-18','2017-01-03 15:31:24','2017-01-03 15:31:24');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('250',0,'2017-01-04','2017-01-04','2017-01-04 18:28:40','2017-01-04 18:28:40');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('251',0,'2017-01-04','2017-01-04','2017-01-04 18:30:42','2017-01-04 18:30:42');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('252',0,'2017-01-04','2017-01-04','2017-01-04 18:39:09','2017-01-04 18:31:00');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('26',40,'2017-01-11','2017-01-21','2017-01-03 15:32:02','2017-01-03 15:32:02');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('27',2,'2017-01-03','2017-01-26','2017-01-03 15:33:25','2017-01-03 15:33:25');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('28',12,'2017-01-04','2017-01-12','2017-01-03 15:38:09','2017-01-03 15:38:09');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('29',0,'2017-01-03','2017-01-03','2017-01-03 15:38:54','2017-01-03 15:38:54');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('3',0,'2017-01-03','2017-01-03','2017-01-03 00:54:02','2017-01-03 00:54:02');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('30',0,'2017-01-03','2017-01-27','2017-01-03 15:39:28','2017-01-03 15:39:28');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('31',0,'2017-01-03','2017-01-03','2017-01-03 15:40:00','2017-01-03 15:40:00');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('32',10,'2017-01-12','2017-01-31','2017-01-03 15:42:46','2017-01-03 15:42:46');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('33',0,'2017-01-03','2017-01-03','2017-01-03 15:43:34','2017-01-03 15:43:34');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('34',2,'2017-01-03','2017-02-03','2017-01-03 15:43:43','2017-01-03 15:43:43');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('35',3,'2017-01-03','2017-01-27','2017-01-03 15:47:44','2017-01-03 15:47:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('36',0,'2017-01-03','2017-01-03','2017-01-03 15:48:42','2017-01-03 15:48:42');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('37',0,'2017-01-03','2017-01-03','2017-01-03 15:49:56','2017-01-03 15:49:56');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('38',30,'2017-01-05','2017-01-12','2017-01-03 15:51:26','2017-01-03 15:51:26');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('39',2,'2017-01-03','2017-02-03','2017-01-03 15:51:59','2017-01-03 15:51:59');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('4',67,'2012-12-16','2012-12-18','2017-01-03 00:54:45','2017-01-03 00:54:45');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('40',10,'2017-01-05','2017-01-13','2017-01-03 15:52:56','2017-01-03 15:52:56');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('41',15,'2017-01-06','2017-01-14','2017-01-03 15:54:40','2017-01-03 15:54:40');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('42',50,'2017-01-07','2017-01-11','2017-01-03 15:56:33','2017-01-03 15:55:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('44',0,'2017-01-03','2017-01-03','2017-01-03 15:57:27','2017-01-03 15:57:27');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('45',2,'2017-01-03','2017-02-03','2017-01-03 15:58:22','2017-01-03 15:58:22');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('46',2,'2017-01-03','2017-02-03','2017-01-03 18:09:15','2017-01-03 18:09:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('47',0,'2017-01-03','2017-01-03','2017-01-03 18:12:46','2017-01-03 18:12:46');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('48',0,'2017-01-03','2017-01-03','2017-01-03 18:12:47','2017-01-03 18:12:47');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('49',0,'2017-01-03','2017-01-03','2017-01-03 18:14:22','2017-01-03 18:14:22');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('5',12,'2017-01-03','2017-01-20','2017-01-03 14:54:57','2017-01-03 14:54:06');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('50',0,'2017-01-03','2017-01-03','2017-01-03 18:15:06','2017-01-03 18:15:06');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('51',2,'2017-01-03','2017-02-03','2017-01-03 18:15:08','2017-01-03 18:15:08');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('52',10,'2017-01-05','2017-01-12','2017-01-03 18:18:48','2017-01-03 18:18:48');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('53',5,'2017-01-03','2017-02-03','2017-01-03 18:27:18','2017-01-03 18:27:18');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('54',0,'2017-01-03','2017-01-03','2017-01-03 18:29:12','2017-01-03 18:29:12');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('55',0,'2017-01-03','2017-01-03','2017-01-03 18:30:15','2017-01-03 18:30:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('56',0,'2017-01-03','2017-01-03','2017-01-03 18:30:15','2017-01-03 18:30:15');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('57',5,'2017-01-03','2017-01-03','2017-01-03 18:31:26','2017-01-03 18:31:26');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('58',25,'2017-01-06','2017-01-13','2017-01-03 18:32:41','2017-01-03 18:32:41');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('59',0,'2017-01-03','2017-01-03','2017-01-03 18:33:26','2017-01-03 18:33:26');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('6',5,'2017-01-03','2017-02-03','2017-01-03 14:58:19','2017-01-03 14:56:04');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('60',0,'2017-01-03','2017-01-03','2017-01-03 18:34:25','2017-01-03 18:34:25');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('61',15,'2017-01-03','2017-02-03','2017-01-03 18:34:37','2017-01-03 18:34:37');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('62',0,'2017-01-03','2017-01-03','2017-01-03 18:36:19','2017-01-03 18:36:19');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('63',10,'2017-01-03','2017-02-03','2017-01-03 18:39:10','2017-01-03 18:39:10');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('64',15,'2017-01-03','2017-01-10','2017-01-03 18:42:05','2017-01-03 18:42:05');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('65',0,'2017-01-03','2017-01-03','2017-01-03 18:42:49','2017-01-03 18:42:49');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('66',0,'2017-01-03','2017-01-03','2017-01-03 18:43:54','2017-01-03 18:43:54');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('67',0,'2017-01-03','2017-01-03','2017-01-03 18:43:55','2017-01-03 18:43:55');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('68',0,'2017-01-03','2017-01-03','2017-01-03 18:44:31','2017-01-03 18:44:31');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('69',60,'2017-01-03','2017-02-03','2017-01-03 18:47:44','2017-01-03 18:47:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('7',10,'2017-01-03','2017-01-20','2017-01-03 15:00:44','2017-01-03 15:00:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('70',0,'2017-01-03','2017-01-03','2017-01-03 18:49:31','2017-01-03 18:49:31');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('71',0,'2017-01-03','2017-01-03','2017-01-03 18:49:31','2017-01-03 18:49:31');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('72',0,'2017-01-03','2017-01-03','2017-01-03 18:50:22','2017-01-03 18:50:22');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('73',0,'2017-01-03','2017-01-03','2017-01-03 18:51:10','2017-01-03 18:51:10');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('74',0,'2017-01-03','2017-01-03','2017-01-03 18:51:58','2017-01-03 18:51:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('76',0,'2017-01-03','2017-01-03','2017-01-03 18:51:58','2017-01-03 18:51:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('78',0,'2017-01-03','2017-01-03','2017-01-03 18:51:58','2017-01-03 18:51:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('79',12,'2017-01-03','2017-02-03','2017-01-03 18:53:43','2017-01-03 18:53:43');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('8',6,'2017-01-03','2017-01-14','2017-01-03 15:01:54','2017-01-03 15:01:54');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('80',25,'2017-01-03','2017-02-03','2017-01-03 18:56:54','2017-01-03 18:56:54');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('81',0,'2017-01-03','2017-01-03','2017-01-03 18:58:00','2017-01-03 18:58:00');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('82',0,'2017-01-03','2017-01-03','2017-01-03 18:58:44','2017-01-03 18:58:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('83',0,'2017-01-03','2017-01-03','2017-01-03 18:59:29','2017-01-03 18:59:29');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('84',0,'2017-01-03','2017-01-03','2017-01-03 19:00:07','2017-01-03 19:00:07');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('85',0,'2017-01-03','2017-01-03','2017-01-03 19:00:44','2017-01-03 19:00:44');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('86',50,'2017-01-03','2017-02-03','2017-01-03 19:02:57','2017-01-03 19:02:57');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('87',0,'2017-01-03','2017-01-03','2017-01-03 19:04:17','2017-01-03 19:04:17');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('88',0,'2017-01-03','2017-01-03','2017-01-03 19:05:31','2017-01-03 19:05:31');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('89',45,'2017-01-03','2017-02-03','2017-01-03 19:06:51','2017-01-03 19:06:51');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('9',5,'2017-01-03','2017-01-19','2017-01-03 15:03:11','2017-01-03 15:03:11');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('90',0,'2017-01-03','2017-01-03','2017-01-03 19:10:58','2017-01-03 19:10:58');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('91',0,'2017-01-03','2017-01-03','2017-01-03 19:11:49','2017-01-03 19:11:49');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('92',0,'2017-01-03','2017-01-03','2017-01-03 19:12:36','2017-01-03 19:12:36');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('93',60,'2017-01-03','2017-02-03','2017-01-03 19:14:09','2017-01-03 19:14:09');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('94',0,'2017-01-03','2017-01-03','2017-01-03 19:18:25','2017-01-03 19:18:25');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('95',0,'2017-01-03','2017-01-03','2017-01-03 19:19:08','2017-01-03 19:19:08');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('96',0,'2017-01-03','2017-01-03','2017-01-03 19:20:28','2017-01-03 19:20:28');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('97',0,'2017-01-03','2017-01-03','2017-01-03 19:21:11','2017-01-03 19:21:11');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('98',0,'2017-01-03','2017-01-03','2017-01-03 19:25:55','2017-01-03 19:25:55');
INSERT INTO `offer_details` (`product_id`,`offer`,`from_date`,`to_date`,`modify_date`,`added_date`) VALUES ('99',0,'2017-01-03','2017-01-03','2017-01-03 19:26:42','2017-01-03 19:26:42');
